package com.react.projectInfo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String stuname;
	private String email;
	private String phoneno;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getEmail() {
		return email;
	}
	
	public Student(int id, String stuname, String email, String phoneno) {
		super();
		this.id = id;
		this.stuname = stuname;
		this.email = email;
		this.phoneno = phoneno;
	}
	
	public Student(String stuname, String email, String phoneno) {
		super();
		this.stuname = stuname;
		this.email = email;
		this.phoneno = phoneno;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
