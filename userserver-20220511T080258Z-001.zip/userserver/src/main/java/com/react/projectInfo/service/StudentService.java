package com.react.projectInfo.service;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.react.projectInfo.Model.Student;
import com.react.projectInfo.repository.StudentRepository;

@Service
public class StudentService {
 
	@Autowired
	private StudentRepository repository;
	
	public Student saveStudent(Student student) {
		return repository.save(student);
	}

	public List<Student> getAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	
}
