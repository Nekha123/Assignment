package com.nagarro.projectInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
