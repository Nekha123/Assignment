import logo from './logo.svg';
import React from 'react';

import './App.css';
import ListEmployeeComponent from './components/ListEmployeeComponent';
import HeaderComponent from './components/HeaderComponent';
import CreateEmployeeComponent from './components/CreateEmployeeComponent';

import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'

function App() {
  return (
    <div>
     <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 
                          <Route exact path = "/"  component = {ListEmployeeComponent}></Route>
                          <Route exact path = "/employees"   component = {ListEmployeeComponent}></Route>
                          <Route exact path = "/add-employee"  component = {CreateEmployeeComponent}></Route>
                    </Switch>
                </div>
                
            
        </Router>
    
    </div>
  );
}

export default App;
