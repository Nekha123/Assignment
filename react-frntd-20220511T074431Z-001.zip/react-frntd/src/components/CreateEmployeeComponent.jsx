import React, { Component } from 'react'

import EmployeeService from '../services/EmployeeService';

class CreateEmployeeComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            firstName: '',
            emailId: '',
            phoneno: ''
           
        }
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);

        this.changeEamilHandler = this.changeEmailHandler.bind(this);
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
        
    }

    saveOrUpdateEmployee = (e) => {
        e.preventDefault();
        let employee = {stuname: this.state.firstName, email: this.state.emailId, phoneno: this.state.phoneno};
        console.log('employee => ' + JSON.stringify(employee));
   
        EmployeeService.createEmployee(employee).then(res =>{
            this.props.history.push('/employees');
        });
        
    }
    changeFirstNameHandler= (event) => {
        this.setState({firstName: event.target.value});
    }

    changeEmailHandler= (event) => {
        this.setState({emailId: event.target.value});
    }

    changePhonenoHandler= (event) => {
        this.setState({phoneno: event.target.value});
    }
    
    cancel(){
        this.props.history.push('/employees');
    }
    render() {
        return (
            <div>
            <br></br>
               <div className = "container">
                    <div className = "row">
                        <div className = "card col-md-6 offset-md-3 offset-md-3">
                            
                            <div className = "card-body">
                                <form>
                                    <div className = "form-group">
                                        <label> Employee Name: </label>
                                        <input placeholder="First Name" name="firstName" className="form-control" 
                                            value={this.state.firstName} onChange={this.changeFirstNameHandler}/>
                                    </div>
                                    <div className = "form-group">
                                        <label> Email: </label>
                                        <input placeholder="Email ..." name="emailID" className="form-control" 
                                            value={this.state.emailId} onChange={this.changeEmailHandler}/>
                                    </div>
                                    <div className = "form-group">
                                        <label> Phone No: </label>
                                        <input placeholder="Phone no" name="phoneno" className="form-control" 
                                            value={this.state.phoneno} onChange={this.changePhonenoHandler}/>
                                    </div>

                                    <button className="btn btn-success md-2" onClick={this.saveOrUpdateEmployee}>Save</button>

                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>

               </div>
            </div>
        )
    }
}

export default CreateEmployeeComponent