import axios from 'axios';

const EMPLOYEE_API_BASE_URL1 = "http://localhost:8085/student";
const EMPLOYEE_API_BASE_URL2 = "http://localhost:8085/addstudent";

class EmployeeService {

    getEmployees(){
        return axios.get(EMPLOYEE_API_BASE_URL1);
    }

    createEmployee(employee){
        console.log('hello');
        return axios.post(EMPLOYEE_API_BASE_URL2, employee);
    }
}

export default new EmployeeService()